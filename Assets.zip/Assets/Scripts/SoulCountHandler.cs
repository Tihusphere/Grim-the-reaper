using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class SoulCountHandler : MonoBehaviour
{
    [SerializeField] TMP_Text Obj = null;
    static int souls = 10;

     void Start()
    {
        Obj.text = " 10 ";
    }
    void OnMouseDown() 
    {
        souls = souls-1;
        string newval = $" {souls} ";
        Obj.text = newval;

        if (souls == 0) 
        {
            Debug.Log("Yeu be don!");
            SceneManager.LoadScene(2);
        }

    }
}
