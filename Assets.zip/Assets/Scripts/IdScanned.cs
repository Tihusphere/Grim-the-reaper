using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class IdScanned : MonoBehaviour
{
    [SerializeField] private string n;
    [SerializeField] TMP_Text G1 = null;
    [SerializeField] TMP_Text G2 = null;
    [SerializeField] TMP_Text G3 = null;
    [SerializeField] TMP_Text B1 = null;
    [SerializeField] TMP_Text B2 = null;
    [SerializeField] TMP_Text B3 = null;

    public int randNum;

    string[] G1S = {"1. Helped old people", "1. Picked up trash", "1. Did homework", "1. Said 'Hi' to people"};
    string[] G2S = {"2. Hugged Squirrel", "2. Charged Phone", "2. Made a company", "2. Ate healthy foodas"};
    string[] G3S = {"3. Stopped Theif", "3. Planted Tree", "3. Cleaned Ocean", "3. Hugged Mom"};

    string[] B1S = {"1. Kicked Dog", "1. Threw rock at cat", "1. Ate floor food", "1. Littered"};
    string[] B2S = {"2. Said swear words", "2. Stepped on bugs", "2. Stabbed friend", "2. Stole diamonds"};
    string[] B3S = {"3. Ate frog", "3. Was mean to store people", "3. Threw Chair at teacher", "3. Set off Nuke"};

    void Start() 
    {
        G1.text = null;
        G2.text = null;
        G3.text = null;
        B1.text = null;
        B2.text = null;
        B3.text = null;     
    }

    void OnCollisionEnter(Collision col) 
    {
        if (col.gameObject.name == n)
        {
            randNum = Random.Range(0,4);
            G1.text = G1S[randNum];
            randNum = Random.Range(0,4);
            G2.text = G2S[randNum];
            randNum = Random.Range(0,4);
            G3.text = G3S[randNum];
            randNum = Random.Range(0,4);
            B1.text = B1S[randNum];
            randNum = Random.Range(0,4);
            B2.text = B2S[randNum];
            randNum = Random.Range(0,4);
            B3.text = B3S[randNum];
        }   
        else
        {
            G1.text = null;
            G2.text = null;
            G3.text = null;
            B1.text = null;
            B2.text = null;
            B3.text = null;
        } 
    }
}
