using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class HeavenButtonScript : MonoBehaviour
{
    Animator anim;
    Animator SpiritComponent;

    public GameObject spirit;

    [SerializeField] GameObject id;
    
    [SerializeField] TMP_Text G1 = null;
    [SerializeField] TMP_Text G2 = null;
    [SerializeField] TMP_Text G3 = null;
    [SerializeField] TMP_Text B1 = null;
    [SerializeField] TMP_Text B2 = null;
    [SerializeField] TMP_Text B3 = null;

    [SerializeField] TMP_Text Rating = null;

     void Start()
    {
        anim = gameObject.GetComponent<Animator>();
        SpiritComponent = spirit.GetComponent<Animator>();
    }
    void OnMouseDown() 
    {
        anim.SetTrigger("Active");
        SpiritComponent.SetTrigger("Heaven");
        
        spirit.transform.position = new Vector3(0.8f,46.9f,24.71f);
        id.transform.position = new Vector3(3.940001f, 2.96f, -15.1f);

        SpiritComponent.SetTrigger("Fall");

        G1.text = null;
        G2.text = null;
        G3.text = null;
        B1.text = null;
        B2.text = null;
        B3.text = null; 

        Rating.text = "I think they should go to hell but whatever.";
    }
}